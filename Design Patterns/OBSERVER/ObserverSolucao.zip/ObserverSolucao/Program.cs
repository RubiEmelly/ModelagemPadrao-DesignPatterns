﻿using System;
using ObserverSolucao.Observers;
using ObserverSolucao.Subjects;

namespace ObserverSolucao
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Newsletter newsletter = new Newsletter();

            Funcionario funcionario1 = new Funcionario("Func01", "func01@teste.com");
            newsletter.registerObserver(funcionario1);
            Funcionario funcionario2 = new Funcionario("Func02", "func02@teste.com");
            newsletter.registerObserver(funcionario2);

            Cliente cliente = new Cliente("Cli01", "cli01@teste.com");
            newsletter.registerObserver(cliente);

            Parceiro parceiro = new Parceiro("Parca01", "parca01@teste.com");
            newsletter.registerObserver(parceiro);

            Fornecedor fornecedor = new Fornecedor("forn01", "forn01@teste.com");
            newsletter.registerObserver(fornecedor);

            Console.WriteLine("-----------TESTE PRIMEIRA MENSAGEM--------------------");
            newsletter.addMessage("Primeira Mensagem");

            newsletter.removeObserver(funcionario2);
            Console.WriteLine("-----------TESTE SEGUNDA MENSAGEM--------------------");
            newsletter.addMessage("Segunda Mensagem");

            newsletter.registerObserver(funcionario2);
            Console.WriteLine("-----------TESTE TERCEIRA MENSAGEM--------------------");
            newsletter.addMessage("Terceira Mensagem");
        }
    }
}
