﻿using FactoryMethodProblema.boletobancario;
using FactoryMethodProblema.boletobancario.Bancodobrasil;
using FactoryMethodProblema.boletobancario.Caixa;

Console.WriteLine("--------------CAIXA--------------");
BancoCaixa bancoCaixa = new BancoCaixa();
bancoCaixa.gerarBoleto(10, 100);
bancoCaixa.gerarBoleto(30, 100);
bancoCaixa.gerarBoleto(60, 100);

Console.WriteLine("--------------BANCO DO BRASIL--------------");
BancoDoBrasil bancoBrasil = new BancoDoBrasil();
bancoBrasil.gerarBoleto(10, 100);
bancoBrasil.gerarBoleto(30, 100);
bancoBrasil.gerarBoleto(60, 100);