﻿using StrategyCenario4.Fretes;
using StrategyCenario4.Pedidos;

try
{
    Frete freteComum = new FreteComum();
    Frete freteExpresso = new FreteExpresso();

    Pedido pedidoEletro = new PedidoEletronicos();

    pedidoEletro.valor = 100;

    pedidoEletro.tipoFrete = freteComum;

    Console.WriteLine("Frete Comum " + pedidoEletro.nomeSetor + " R$" + pedidoEletro.calculaFrete());

    pedidoEletro.tipoFrete = freteExpresso;

    Console.WriteLine("Frete Comum " + pedidoEletro.nomeSetor + " R$" + pedidoEletro.calculaFrete());
}
catch (Exception e)
{
    Console.WriteLine(e.ToString());
}