﻿using StrategyCenario3.Pedido;

try 
{
    Pedido pedidoEletro = new PedidoEletronicos();

    pedidoEletro.valor = 100;

    Console.WriteLine("Frete Comum " + pedidoEletro.nomeSetor + " R$" + pedidoEletro.calculaFreteComum());
    Console.WriteLine("Frete Comum " + pedidoEletro.nomeSetor + " R$" + pedidoEletro.calculaFreteExpresso());



    Pedido pedidoMoveis = new PedidoMoveis();

    pedidoMoveis.valor = 100;

    Console.WriteLine("Frete Comum " + pedidoMoveis.nomeSetor + " R$" + pedidoMoveis.calculaFreteComum());
    Console.WriteLine("Frete Comum " + pedidoMoveis.nomeSetor + " R$" + pedidoMoveis.calculaFreteExpresso());
}
catch (Exception e)
{
    Console.WriteLine(e.ToString());
}