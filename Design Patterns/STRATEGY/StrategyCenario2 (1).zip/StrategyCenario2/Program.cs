﻿using StrategyCenario2.Pedidos;

Pedido pedidoEletro = new PedidoEletronicos();

pedidoEletro.valor = 100;

Console.WriteLine("Frete Comum "+pedidoEletro.nomeSetor+" R$"+pedidoEletro.calculaFreteComum());
Console.WriteLine("Frete Comum " + pedidoEletro.nomeSetor + " R$" + pedidoEletro.calculaFreteExpresso());