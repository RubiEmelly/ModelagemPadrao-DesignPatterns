﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StateSolucao01.domains.enums
{
    enum StatusPedido
    {
        AGUARDANDO_PAGAMENTO=1,
        PAGO=2,
        CANCELADO=3,
        ENVIADO=4
    }
}
