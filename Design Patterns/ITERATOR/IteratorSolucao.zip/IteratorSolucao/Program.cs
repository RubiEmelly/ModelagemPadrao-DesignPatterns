﻿using IteratorSolucao.IteratorModel;

List<int> lista = [1, 2, 3, 4, 5, 6, 7, 8, 9];
List<List<int>> matriz = [[1, 2, 3], [4, 5, 6], [7, 8, 9]];

Iterator listaIterator = new ListaIterator(lista);
Iterator matrizIterator = new MatrizIterator(matriz);

Console.WriteLine("Lista - vetor");
ImpressoraDeAgregados.iterar(listaIterator);

Console.WriteLine("Matriz");
ImpressoraDeAgregados.iterar(matrizIterator);