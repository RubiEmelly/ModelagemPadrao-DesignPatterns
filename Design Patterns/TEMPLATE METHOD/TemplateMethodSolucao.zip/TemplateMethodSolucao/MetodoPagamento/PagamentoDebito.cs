﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TemplateMethodProblema1.GatewayCobranca;
using TemplateMethodSolucao.MetodoPagamento;

namespace TemplateMethodSolucao.MetodoPagamento
{
    public class PagamentoDebito : Pagamento
    {
        public PagamentoDebito(double valor, Gateway gateway)
        {
            base.valor = valor;
            base.gateway = gateway;
        }
        public double calcularTaxa()
        {
            return 4;
        }

        public override double calcularDesconto()
        {
            if (this.valor > 300)
                return this.valor * 0.05;
            else return 0;
        }
        public Boolean realizaCobranca()
        {
            double valorPago =
                this.valor + this.calcularTaxa()
                - this.calcularDesconto();
            return this.gateway.cobrar(valorPago);
        }
    }
}
